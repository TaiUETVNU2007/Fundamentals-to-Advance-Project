// Decoder giải mã trạng thái ra tín hiệu One-Hot
module Decoder (
    input  wire [1:0] data_in,
    output reg  [3:0] signal
);
    always @(*) begin
        case (data_in)
            2'b00: signal = 4'b0001; // S0 active
            2'b01: signal = 4'b0010; // S1 active
            2'b10: signal = 4'b0100; // S2 active
            2'b11: signal = 4'b1000; // S3 active
            default: signal = 4'b0000;
        endcase
    end
endmodule